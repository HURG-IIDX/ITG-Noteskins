local t = Def.Model {
	Meshes="_mine model.txt";
	Materials="_mine model.txt";
	Bones="_mine model.txt";
};

return t;

